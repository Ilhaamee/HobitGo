-- ============================================================
-- HOBITGO — Solo lo que falta en tu base de datos
-- Ejecuta esto en el SQL Editor de Supabase
-- ============================================================

-- 1. VIEW del Leaderboard (no existe, la app la necesita)
CREATE OR REPLACE VIEW leaderboard AS
SELECT
  p.id,
  p.username,
  p.avatar_url,
  COALESCE(SUM(al.points), 0)::INTEGER        AS total_points,
  COALESCE(COUNT(DISTINCT g.id) FILTER (WHERE g.completed = TRUE), 0)::INTEGER AS goals_completed,
  COALESCE(COUNT(DISTINCT h.id), 0)::INTEGER  AS hobbies_count
FROM profiles p
LEFT JOIN activity_log al ON al.user_id = p.id
LEFT JOIN goals         g  ON g.user_id  = p.id
LEFT JOIN hobbies       h  ON h.user_id  = p.id
GROUP BY p.id, p.username, p.avatar_url
ORDER BY total_points DESC;

GRANT SELECT ON leaderboard TO authenticated;


-- 2. Trigger para crear perfil automático al registrarse con Google
--    (sin esto, el login con Google no crea perfil y rompe el onboarding)
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
DECLARE
  base_username  TEXT;
  final_username TEXT;
  counter        INTEGER := 0;
BEGIN
  base_username := COALESCE(
    NEW.raw_user_meta_data->>'name',
    split_part(NEW.email, '@', 1)
  );
  base_username  := regexp_replace(base_username, '[^a-zA-Z0-9_]', '', 'g');
  IF length(base_username) < 3 THEN base_username := 'user' || base_username; END IF;
  base_username  := left(base_username, 20);
  final_username := base_username;

  WHILE EXISTS (SELECT 1 FROM profiles WHERE username = final_username) LOOP
    counter        := counter + 1;
    final_username := base_username || counter::TEXT;
  END LOOP;

  INSERT INTO profiles (id, username, avatar_url, onboarding_done)
  VALUES (
    NEW.id,
    final_username,
    NEW.raw_user_meta_data->>'avatar_url',
    FALSE
  )
  ON CONFLICT (id) DO NOTHING;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();


-- 3. Habilitar Realtime en las tablas de chat (si no lo está ya)
ALTER PUBLICATION supabase_realtime ADD TABLE community_messages;
ALTER PUBLICATION supabase_realtime ADD TABLE private_messages;
