-- ============================================================
-- HOBITGO - Schema completo de Supabase
-- Ejecuta este script en el SQL Editor de tu proyecto Supabase
-- ============================================================

-- ========================
-- 1. PROFILES
-- ========================
CREATE TABLE IF NOT EXISTS profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username TEXT UNIQUE NOT NULL,
  bio TEXT,
  avatar_url TEXT,
  dark_mode BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view all profiles" ON profiles FOR SELECT USING (true);
CREATE POLICY "Users can insert own profile" ON profiles FOR INSERT WITH CHECK (auth.uid() = id);
CREATE POLICY "Users can update own profile" ON profiles FOR UPDATE USING (auth.uid() = id);

-- ========================
-- 2. HOBBIES
-- ========================
CREATE TABLE IF NOT EXISTS hobbies (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  name TEXT NOT NULL,
  description TEXT,
  icon TEXT DEFAULT 'book',
  color TEXT DEFAULT '#E08E6B',
  image_url TEXT,
  total_minutes INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE hobbies ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can manage own hobbies" ON hobbies USING (auth.uid() = user_id);

-- ========================
-- 3. HOBBY SESSIONS
-- ========================
CREATE TABLE IF NOT EXISTS hobby_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  hobby_id UUID REFERENCES hobbies(id) ON DELETE CASCADE NOT NULL,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  minutes INTEGER NOT NULL,
  note TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE hobby_sessions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can manage own hobby sessions" ON hobby_sessions USING (auth.uid() = user_id);

-- ========================
-- 4. EVENTS (Calendario)
-- ========================
CREATE TABLE IF NOT EXISTS events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  date DATE NOT NULL,
  start_time TIME,
  end_time TIME,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE events ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can manage own events" ON events USING (auth.uid() = user_id);

-- ========================
-- 5. GOALS (Retos de 30 días)
-- ========================
CREATE TABLE IF NOT EXISTS goals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  title TEXT NOT NULL,
  total_days INTEGER DEFAULT 30 CHECK (total_days >= 30),
  current_day INTEGER DEFAULT 0,
  last_checked_in DATE,
  completed BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE goals ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can manage own goals" ON goals USING (auth.uid() = user_id);

-- ========================
-- 6. ACTIVITY LOG
-- ========================
CREATE TABLE IF NOT EXISTS activity_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  type TEXT NOT NULL CHECK (type IN ('event', 'hobby', 'challenge', 'message')),
  title TEXT NOT NULL,
  points INTEGER DEFAULT 0,
  activity_date DATE DEFAULT CURRENT_DATE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE activity_log ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own activity" ON activity_log FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own activity" ON activity_log FOR INSERT WITH CHECK (auth.uid() = user_id);

-- ========================
-- 7. COMMUNITY MESSAGES (Chat público)
-- ========================
CREATE TABLE IF NOT EXISTS community_messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  username TEXT NOT NULL,
  content TEXT,
  image_url TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  CONSTRAINT content_or_image CHECK (content IS NOT NULL OR image_url IS NOT NULL)
);

ALTER TABLE community_messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read community messages" ON community_messages FOR SELECT USING (true);
CREATE POLICY "Authenticated users can insert community messages" ON community_messages FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Habilitar Realtime para community_messages
ALTER PUBLICATION supabase_realtime ADD TABLE community_messages;

-- ========================
-- 8. PRIVATE MESSAGES (Mensajes privados)
-- ========================
CREATE TABLE IF NOT EXISTS private_messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  sender_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  receiver_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  content TEXT,
  image_url TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  CONSTRAINT content_or_image CHECK (content IS NOT NULL OR image_url IS NOT NULL)
);

ALTER TABLE private_messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read their own private messages" ON private_messages
  FOR SELECT USING (auth.uid() = sender_id OR auth.uid() = receiver_id);

CREATE POLICY "Users can send private messages" ON private_messages
  FOR INSERT WITH CHECK (auth.uid() = sender_id);

-- Habilitar Realtime para private_messages
ALTER PUBLICATION supabase_realtime ADD TABLE private_messages;

-- ========================
-- 9. LEADERBOARD VIEW
-- ========================
-- Vista que agrega puntos, retos y hobbies por usuario para el ranking
CREATE OR REPLACE VIEW leaderboard AS
SELECT
  p.id,
  p.username,
  p.avatar_url,
  COALESCE(SUM(al.points), 0)::INTEGER AS total_points,
  COALESCE(COUNT(DISTINCT g.id) FILTER (WHERE g.completed = TRUE), 0)::INTEGER AS goals_completed,
  COALESCE(COUNT(DISTINCT h.id), 0)::INTEGER AS hobbies_count
FROM profiles p
LEFT JOIN activity_log al ON al.user_id = p.id
LEFT JOIN goals g ON g.user_id = p.id
LEFT JOIN hobbies h ON h.user_id = p.id
GROUP BY p.id, p.username, p.avatar_url
ORDER BY total_points DESC;

-- Dar acceso de lectura a la view para usuarios autenticados
GRANT SELECT ON leaderboard TO authenticated;

-- ========================
-- 10. STORAGE BUCKETS
-- ========================
-- Ejecuta esto en Storage > Buckets o en el SQL Editor

INSERT INTO storage.buckets (id, name, public)
VALUES ('avatars', 'avatars', TRUE)
ON CONFLICT (id) DO NOTHING;

INSERT INTO storage.buckets (id, name, public)
VALUES ('hobbies', 'hobbies', TRUE)
ON CONFLICT (id) DO NOTHING;

INSERT INTO storage.buckets (id, name, public)
VALUES ('chat-images', 'chat-images', TRUE)
ON CONFLICT (id) DO NOTHING;

-- Políticas de storage: cualquier usuario autenticado puede subir/ver
CREATE POLICY "Authenticated users can upload avatars"
  ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'avatars');

CREATE POLICY "Public can view avatars"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'avatars');

CREATE POLICY "Authenticated users can upload hobby images"
  ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'hobbies');

CREATE POLICY "Public can view hobby images"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'hobbies');

CREATE POLICY "Authenticated users can upload chat images"
  ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'chat-images');

CREATE POLICY "Public can view chat images"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'chat-images');

-- ========================
-- 11. ÍNDICES (performance)
-- ========================
CREATE INDEX IF NOT EXISTS idx_activity_log_user_id ON activity_log(user_id);
CREATE INDEX IF NOT EXISTS idx_activity_log_date ON activity_log(activity_date);
CREATE INDEX IF NOT EXISTS idx_goals_user_id ON goals(user_id);
CREATE INDEX IF NOT EXISTS idx_hobbies_user_id ON hobbies(user_id);
CREATE INDEX IF NOT EXISTS idx_hobby_sessions_user_id ON hobby_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_hobby_sessions_hobby_id ON hobby_sessions(hobby_id);
CREATE INDEX IF NOT EXISTS idx_events_user_id ON events(user_id);
CREATE INDEX IF NOT EXISTS idx_events_date ON events(date);
CREATE INDEX IF NOT EXISTS idx_community_messages_created_at ON community_messages(created_at);
CREATE INDEX IF NOT EXISTS idx_private_messages_sender ON private_messages(sender_id);
CREATE INDEX IF NOT EXISTS idx_private_messages_receiver ON private_messages(receiver_id);

-- ========================
-- 12. FUNCIÓN AUTO-CREAR PROFILE
-- ========================
-- Crea un perfil automáticamente cuando un usuario se registra via OAuth (Google)
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
DECLARE
  base_username TEXT;
  final_username TEXT;
  counter INTEGER := 0;
BEGIN
  -- Intentar sacar el nombre del email o metadata de Google
  base_username := COALESCE(
    NEW.raw_user_meta_data->>'name',
    split_part(NEW.email, '@', 1)
  );
  -- Limpiar caracteres especiales
  base_username := regexp_replace(base_username, '[^a-zA-Z0-9_]', '', 'g');
  -- Asegurar mínimo 3 caracteres
  IF length(base_username) < 3 THEN
    base_username := 'user' || base_username;
  END IF;
  -- Truncar a 20 caracteres
  base_username := left(base_username, 20);

  final_username := base_username;

  -- Resolver conflictos de username
  WHILE EXISTS (SELECT 1 FROM profiles WHERE username = final_username) LOOP
    counter := counter + 1;
    final_username := base_username || counter::TEXT;
  END LOOP;

  INSERT INTO profiles (id, username, avatar_url)
  VALUES (
    NEW.id,
    final_username,
    NEW.raw_user_meta_data->>'avatar_url'
  )
  ON CONFLICT (id) DO NOTHING;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger que se dispara al crear un nuevo usuario
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();
